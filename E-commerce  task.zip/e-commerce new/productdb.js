const mongoose = require("mongoose");
let productSchema = new mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    productname: String,
    rate:Number,
    discription: String
  });

  
  module.exports = mongoose.model('productdb', productSchema);